import { Component } from '@angular/core';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.css'
})
export class ChatComponent {


  imageUrl: string | ArrayBuffer | null = null;

  constructor() { }

  onFileChanged(event: any) {
    const file = event.target.files[0];
  const reader = new FileReader();
  reader.onload = () => {
    this.imageUrl = reader.result as string;
  };
  reader.readAsDataURL(file);
  }
  verificarRaza() {
    // Lógica para verificar la raza de la imagen
    alert('Se verificará la raza')
}
}
